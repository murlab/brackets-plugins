/*:%PLUGIN_LANG%
 * @plugindesc v1.0 %PLUGIN_NAME%
 * @author %AUTHOR%
 * @help %HELP%
 *
 * @param param
 * @text param
 * @desc param
 *
 */
