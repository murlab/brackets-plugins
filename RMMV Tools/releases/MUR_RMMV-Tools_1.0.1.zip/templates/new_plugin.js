//=============================================================================
// %AUTHOR% %PLUGIN_NAME% v1.0
// Copyright (C) %YEAR% %AUTHOR% (%URL%)
// %LICENSE%
// %FREE%
//=============================================================================

%PLUGIN_PARAMS%

(function() {
    var params = PluginManager.parameters('%AUTHOR%_%PLUGIN_NAME%');
    var param = params["param"];

})();
