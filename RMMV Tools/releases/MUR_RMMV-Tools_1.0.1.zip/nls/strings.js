//=============================================================================
// RMMV Tools v1.0
// Copyright (c) 2018 MUR (https://github.com/murlab)
// BSD 3-Clause "New" or "Revised" License
// Free for use with both free and commercial
//=============================================================================

/*jslint vars: true, plusplus: true, devel: true, nomen: true, indent: 4, maxerr: 50, browser: true */
/*global define, brackets, $ */

define(function (require, exports, module) {
	'use strict';
	
	module.exports = {
		"root": true,
		"ru": true
	};
});
